package Exercitiul1.Builder2.clase;



public interface Builder {
    Pacient build();

}
